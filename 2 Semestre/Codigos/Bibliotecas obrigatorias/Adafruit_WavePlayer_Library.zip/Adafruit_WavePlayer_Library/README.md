# Adafruit_WavePlayer [![Build Status](https://github.com/adafruit/Adafruit_WavePlayer/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_WavePlayer/actions)

Helper friend library for tangling with Wav files 
