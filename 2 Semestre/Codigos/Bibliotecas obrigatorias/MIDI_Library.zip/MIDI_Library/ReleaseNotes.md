#### Changelog

-   20/04/2020 : Version 5.0 released. Separation of transports by [@lathoub](https://github.com/lathoub), adds Active Sensing.
-   11/06/2014 : Version 4.2 released. Bug fix for SysEx, overridable template settings.
-   16/04/2014 : Version 4.1 released. Bug fixes regarding running status.
-   13/02/2014 : Version 4.0 released. Moved to GitHub, added multiple instances & software serial support, and a few bug fixes.
-   29/01/2012 : Version 3.2 released. Release notes are [here](http://sourceforge.net/news/?group_id=265194).
-   06/05/2011 : Version 3.1 released. Added [callback](http://playground.arduino.cc/Main/MIDILibraryCallbacks) support.
-   06/03/2011 : Version 3.0 released. Project is now hosted on [SourceForge](http://sourceforge.net/projects/arduinomidilib).
-   14/12/2009 : Version 2.5 released.
-   28/07/2009 : Version 2.0 released.
-   28/03/2009 : Simplified version of MIDI.begin, Fast mode is now on by default.
-   08/03/2009 : Thru method operational. Added some features to enable thru.
