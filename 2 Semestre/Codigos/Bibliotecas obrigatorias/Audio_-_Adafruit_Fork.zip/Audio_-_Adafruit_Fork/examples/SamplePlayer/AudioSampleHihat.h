// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleHihat[5953];
