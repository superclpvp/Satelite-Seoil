extern const unsigned int guitar_d3_note[52184];
